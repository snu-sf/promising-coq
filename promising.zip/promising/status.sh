#!/usr/bin/env bash

egrep -i "(admit|todo)" src/*/*.v
